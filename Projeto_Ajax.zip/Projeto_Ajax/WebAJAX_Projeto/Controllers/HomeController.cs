﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebAJAX_Projeto.Models;

namespace WebAJAX_Projeto.Controllers
{
    public class HomeController : Controller
    {

        private readonly Contexto _contexto;


        public HomeController(Contexto contexto)
        {
            _contexto = contexto;
        }




        public IActionResult Index()
        {

            //var Lista = new List<Usuario>();

            //for (int i = 1; i <= 20; i++)
            //{
            //    Lista.Add(new Usuario { NomeUsuario = string.Concat("Usuario - ", i.ToString()) });
            //}

            //_contexto.Usuario.AddRange(Lista);

            //_contexto.SaveChanges();

            return View();
        }

  
        [HttpPost("/api/ListaUsuario")]
        public JsonResult ListaUsuario()
        {
            var usuarios = _contexto.Usuario.ToList();

            return Json(usuarios);
        }



        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
