﻿var ObjetoAjax = new Object();

ObjetoAjax.ContadorErro = 0;

ObjetoAjax.Atualizar = function () {

    setTimeout(ObjetoAjax.Carregatela, 5000);
}


ObjetoAjax.Carregatela = function () {

    $.ajax({
        type: 'POST',
        timeout: 50000,
        url: "/api/ListaUsuario",
        async: true,
        success: function (dados) {

            $('#conteudo').html('');
            var html = "";

            dados.forEach(function (usuario) {

                html += "<label>" + usuario.nomeUsuario + "</label> <br />";

            });

            $('#conteudo').html(html);


        },
        complete: function () {

            if (ObjetoAjax.ContadorErro < 5) {
                ObjetoAjax.Atualizar();
            }

        },
        statusCode: {
            500: function () {
                ObjetoAjax.ContadorErro++;
            }
        }

    });

}





$(function () {
    ObjetoAjax.Carregatela();
});
